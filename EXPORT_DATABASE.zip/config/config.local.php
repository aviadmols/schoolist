<?php
declare(strict_types=1);

/**
 * Local Development Configuration
 */

// Database connection
safe_define('DB_HOST', getenv('MYSQLHOST') ?: 'interchange.proxy.rlwy.net');
safe_define('DB_PORT', getenv('MYSQLPORT') ?: '31019');
safe_define('DB_NAME', getenv('MYSQLDATABASE') ?: 'railway');
safe_define('DB_USER', getenv('MYSQLUSER') ?: 'root');
safe_define('DB_PASS', getenv('MYSQLPASSWORD') ?: 'pMGLZOfLNqulnpiNecRstgXbrmHrAUpB');
safe_define('DB_PREFIX', 'sl_');

// Base URL
safe_define('BASE_URL', 'http://localhost:8000/');

// Admin settings
safe_define('ADMIN_EMAIL', 'aviadmols@gmail.com');
safe_define('ADMIN_PHONE', '0503222012');
safe_define('ADMIN_MASTER_CODE', '998877');

// 019sms Settings

// SMTP settings
safe_define('SMTP_ENABLED', true);
safe_define('SMTP_HOST', 'smtp.inbox.co.il');
safe_define('SMTP_PORT', 587);
safe_define('SMTP_USER', 'noreply@schoolist.co.il');
safe_define('SMTP_PASS', 'n05rn2wjq5odpggr');

// API Keys
safe_define('OPENAI_API_KEY', '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');
safe_define('SMS_019_TOKEN', 'eyJ0eXAiOiJqd3QiLCJhbGciOiJIUzI1NiJ9.eyJmaXJzdF9rZXkiOiI4MjU0NiIsInNlY29uZF9rZXkiOiI0MjAwOTk5IiwiaXNzdWVkQXQiOiIxOS0wMS0yMDI2IDA5OjM4OjAwIiwidHRsIjo2MzA3MjAwMH0.snBKbbNoNmgGPzVdEWhRPssIw_v5m7gqxVyBkY5p2YY');
safe_define('SMS_SOURCE', '0503222012');
safe_define('SMS_USERNAME', 'Aviadmols');
