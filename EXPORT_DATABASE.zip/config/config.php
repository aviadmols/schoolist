<?php
declare(strict_types=1);

/**
 * Production Configuration
 * Note: Use safe_define to avoid "already defined" warnings.
 */

safe_define('DB_HOST', 'interchange.proxy.rlwy.net:31019');
safe_define('DB_NAME', 'railway');
safe_define('DB_USER', 'root');
safe_define('DB_PASS', 'pMGLZOfLNqulnpiNecRstgXbrmHrAUpB');
safe_define('DB_PREFIX', 'sl_');
safe_define('BASE_URL', 'http://localhost:8000');

// SMTP Settings
safe_define('SMTP_ENABLED', true);
safe_define('SMTP_HOST', 'smtp.inbox.co.il');
safe_define('SMTP_USER', 'noreply@schoolist.co.il');
safe_define('SMTP_PASS', '6s75yp7w32');
