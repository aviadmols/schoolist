// Admin Panel JavaScript

// Admin Panel JavaScript
// Note: Page-specific functions are defined in their respective view files
// This file is for shared admin functionality only

